//
//  CityViewController.swift
//  ClimaWeather
//
//  Created by Sherif  Wagih on 7/3/18.
//  Copyright © 2018 Sherif Wagih. All rights reserved.
//

import UIKit
protocol  changeCityDelegate
{
    func userEnteredANewCityName(city: String);
    
}
class CityViewController: UIViewController {
    
    var formDelegate : changeCityDelegate?;
    
    @IBOutlet weak var cityLabel: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    let weatherModel = WeatherDataModel();
    
    @IBAction func getWeatherButtonPresssed(_ sender: UIButton) {
        formDelegate?.userEnteredANewCityName(city: cityLabel.text!);
        WeatherDataModel.permanentCityName = cityLabel.text!;
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func backButtonPress(_ sender: Any)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
